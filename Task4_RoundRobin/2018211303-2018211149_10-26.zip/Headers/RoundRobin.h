//
// Created by 马嘉骥 on 2020/10/5.
//

#ifndef FINALTEST_ROUNDROBIN_H
#define FINALTEST_ROUNDROBIN_H

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>

void Schedule(int playerNum, std::vector<std::vector<int>> &table);

#endif //FINALTEST_ROUNDROBIN_H
