//
// Created by Ridd on 2020/10/20/020.
//

#ifndef FINALTEST_TEST_H
#define FINALTEST_TEST_H

#include <chrono>

#include "RoundRobin.h"

void PerfTest();

void CorrTest();

#endif //FINALTEST_TEST_H
