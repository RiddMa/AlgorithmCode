//
// Created by 马嘉骥 on 2020/9/28.
//
#undef _HAS_STD_BYTE
#ifndef FINALTEST_MERGESORT_H
#define FINALTEST_MERGESORT_H

#include <cstdlib>
#include <ctime>
#include <iostream>
#include "SortTest.h"

void MergeSort(int *arr, long long size);

#endif //FINALTEST_MERGESORT_H
