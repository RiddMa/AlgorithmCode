//
// Created by 马嘉骥 on 2020/9/29.
//
#undef _HAS_STD_BYTE
#ifndef FINALTEST_QUICKSORT_H
#define FINALTEST_QUICKSORT_H

#include <cstdlib>
#include <ctime>
#include <iostream>
#include "SortTest.h"

void QuickSort(int *arr, long long size, long long left, long long right);

#endif //FINALTEST_QUICKSORT_H
