//
// Created by 马嘉骥 on 2020/9/29.
//
#undef _HAS_STD_BYTE
#ifndef FINALTEST_INSERTIONSORT_H
#define FINALTEST_INSERTIONSORT_H

#include <cstdlib>
#include <ctime>
#include <iostream>
#include "SortTest.h"

void InsertionSort(int *arr, long long SIZE);

#endif //FINALTEST_INSERTIONSORT_H
